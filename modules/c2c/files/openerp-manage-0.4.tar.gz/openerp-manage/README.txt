This file is for you to describe the openerp-manage application. Typically
you would include information such as the information below:

Installation and Setup
======================

Install ``openerp-manage`` using easy_install::

    easy_install openerp-manage

Make a config file as follows::

    paster make-config openerp-manage config.ini

Tweak the config file as appropriate and then setup the application::

    paster setup-app config.ini

Then you are ready to go.
