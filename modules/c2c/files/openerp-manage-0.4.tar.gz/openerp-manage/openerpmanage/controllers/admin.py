import logging,random, smtplib,email.Header,email.MIMEText,ConfigParser,subprocess,time
from commands import getstatus,getoutput,getstatusoutput
from time import sleep
from os import path
from pylons.i18n import get_lang, set_lang


from openerpmanage.lib.base import *

log = logging.getLogger(__name__)

class AdminController(BaseController):

  def __before__(self,action):
    if 'l' in request.params:
      set_lang(request.params['l'])
      session['lang'] = request.params['l']
      session.save()
    elif 'lang' in session:
      set_lang(session['lang'])
    else:
      user_agent_language = request.languages[0][0:2]
      set_lang(user_agent_language)
      session['lang'] = user_agent_language
      session.save()

    if 'user' not in session:
      if action != 'login' and action != 'enter':
        redirect_to(controller="admin",action='login')

  def login(self):
    return render("/login.mako")

  def logout(self):
    for i in session:
      del session[i]
    session.save()
    redirect_to(action='login')

  def enter(self):
    
    if 'login' in request.params:
      config = ConfigParser.ConfigParser()
      config.read('/var/www/openerp-manage.conf')
      pwd = config.get('config','password',0)
      pro = config.get('config','project',0)
      email = config.get('config','email',0)
      if request.params['login'] == 'administrateur' and request.params['pass'] == pwd:
        session['user'] = 'administrateur'
        session['project'] = pro
        session['email'] = email
        session.save()
        redirect_to(controller="admin",action='index')
      else:
        c.error = _(u'An error occurred: we were unable to log you in. Please check your identifants!')
        return render("/login.mako")
    else:
      redirect_to(controller="admin",action='login')


  def index(self):
    # do we have an integration instance ?
    config = ConfigParser.ConfigParser()
    config.read('/srv/openerp/instances/integration/instance.ini')
    onboot = config.get('Main','startonboot',0)
    c.integration = (onboot == "1") 
    c.project = session['project']
    return render("/index.mako")

  def restart(self):
    status, output = getstatusoutput("sudo /etc/init.d/openerp-multi-instances stop")
    c.error = _(u'''The operation completed successfully. Your servers are now up and running.''')
    if status:
      c.error = u'''<h3><img src="/messagebox_warning.png" alt="Error" />%s</h3>%s<div style="height:150px;overflow:auto;width:100%%"><pre>%s</pre></div>''' % (_('''An error occurred.'''), _('''Output is:'''), output)
      return render("/restart.mako")

    sleep(5)
    status, output = getstatusoutput("sudo /etc/init.d/openerp-multi-instances start")
    if status:
      c.error = u'''<h3><img src="/messagebox_warning.png" alt="Error" />%s</h3>%s<div style="height:150px;overflow:auto;width:100%%"><pre>%s</pre></div>''' % (_('''An error occurred.'''), _('''Output is:'''), output)
      return render("/restart.mako")


    return render("/restart.mako")

  def regen(self,id):
    c.which = id
    return render("/confirmregen.mako")

  def doRegen(self,id):
    status,output = getstatusoutput("sudo /usr/local/bin/qa-replicate")
    c.error = _(u'''<p>All is done. Your servers should have been restarted...''')
    if status:
      c.error = u'''<h3><img src="/messagebox_warning.png" alt="Error" />%s</h3>%s<div style="height:150px;overflow:auto;width:100%%"><pre>%s</pre></div>''' % (_('''An error occurred.'''), _('''Output is:'''), output)
    return render("/regenerate.mako")

  def getsources(self,id):
    # tricky : create a tar.gz file from sources, and give a link to download it.
    # first: check if path is really correct (basename, and append rootpath, check existance and so on
    root = '/srv/openerp/instances/'
    instance = path.basename(id)
    archive = "/tmp/%s_%s.tar.gz" %(instance, random.randint(1000,10000))
    fullpath = '%s%s' % (root, instance)

    if path.exists(fullpath) and path.isdir(fullpath):
      status, out = getstatusoutput("cd %s; tar -czpf %s  src" % (fullpath,archive) )
      if status:
	 c.error = u'''<h3><img src="/messagebox_warning.png" alt="Error" />%s</h3>%s<div style="height:150px;overflow:auto;width:100%%"><pre>%s</pre></div>''' % (_('''An error occurred.'''), _('''Output is:'''), output)
      else:
        size = path.getsize(archive)
        response.headers['Content-Type'] = 'application/octet-stream;name=%s.tar.gz' % instance
        response.headers['Content-Length'] = size
        response.headers['Content-Transfer-Encoding'] = "Binary" 
        response.headers['Content-Disposition'] = "attachment; filename=%s.tar.gz" % instance
        for l in open(archive):
          response.write(l)
        pass
    else:
      c.error = u'''<h3><img src="/messagebox_warning.png" alt="Error" />%s</h3>%s<div style="height:150px;overflow:auto;width:100%%"><pre>%s</pre></div>''' % (_('''An error occurred.'''), _('''Output is:'''), output)

    return render("/sources.mako")

  def acceptUpdate(self):
    c.error = ''
    c.done = False
    return render("/acceptUpdate.mako")

  def doAccept(self):
    sender_email = session['email']
    from_header  = 'OpenERP cjeanneret <%s>' % session['email']
    subject      = 'Update OpenERP Hosted "%s"' % session['project']
    recipient_email = 'support_openerp@project.camptocamp.com'
    msg_body     = '''
Hello,

Just to inform you that you can update production instance for "%s" OpenERP.
Please contact your customer when it's done.

Regards,

Your OpenERP Mailer
    ''' % session['project']

    msg = email.MIMEText.MIMEText(msg_body.encode("utf-8"), _subtype="plain", _charset='utf-8')
    msg['Subject'] = email.Header.Header(subject.encode("utf-8"), 'utf-8')
    msg['From']    = from_header
    msg['To']      = recipient_email

    raw_message = msg.as_string()

    c.error = _('''The OpenERP Team will receive an email and process your request as soon as possible. Thank you!''')
    c.done = True
    try:
      server = smtplib.SMTP('psemail.epfl.ch', 25)
    except:
      log.debug("Connection to SMTP server failed!")
      c.error = _('''An error occurred while sending the email (first stage)... Sorry, try again later''')
    try:
      server.sendmail('noreply@camptocamp.com', [recipient_email], raw_message)
    except:
      log.debug("Mail sending failed!")
      c.error = _('''An error occurred while sending the email (second stage)... Sorry, try again later''')
    server.quit()

    return render('/acceptUpdate.mako')


  def doc(self):
    return render("/doc.mako")

  def regenIntegration(self):
    status, output = getstatusoutput('''sudo /usr/local/bin/integration-replicate''')
    c.error = u'''<p>%s</p><div style="height:150px;overflow:auto;width:100%%"><pre>%s</pre></div>''' %(_('Your Integration instance is ready. Here are the logs:'), output)
    if status:
      c.error = u'''<h3><img src="/messagebox_warning.png" alt="Error" />%s</h3>%s<div style="height:150px;overflow:auto;width:100%%"><pre>%s</pre></div>''' % (_('''An error occurred.'''), _('''Output is:'''), output)
    return render('/integration.mako')
